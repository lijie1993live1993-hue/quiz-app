package com.example.offlinesearchquiz.floating
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
object FloatingPermissionHelper {
    fun canDrawOverlay(context: Context) = Settings.canDrawOverlays(context)
    fun openOverlaySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}