package com.example.offlinesearchquiz.camera
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
object OcrProcessor {
    private val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    suspend fun recognize(bitmap: Bitmap): String = suspendCoroutine { cont ->
        recognizer.process(InputImage.fromBitmap(bitmap, 0)).addOnSuccessListener { cont.resume(it.text) }.addOnFailureListener { cont.resume("") }
    }
    fun recognizeImageProxy(imageProxy: androidx.camera.core.ImageProxy, onSuccess: (String) -> Unit, onFailure: () -> Unit) {
        val mediaImage = imageProxy.image ?: return onFailure()
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        recognizer.process(image)
            .addOnSuccessListener { onSuccess(it.text) }
            .addOnFailureListener { onFailure() }
    }
}