package com.example.offlinesearchquiz.data
import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
class QuestionRepository(private val context: Context) {
    private val dao = AppDatabase.get(context).questionDao()
    suspend fun importFromJsonText(jsonText: String, clearFirst: Boolean = false) {
        val type = object : TypeToken<List<QuestionEntity>>() {}.type
        val list: List<QuestionEntity> = Gson().fromJson(jsonText, type) ?: throw IllegalArgumentException("解析为空")
        if (list.isEmpty()) throw IllegalArgumentException("题库为空")
        if (clearFirst) dao.clearAll()
        dao.insertAll(list)
    }
    suspend fun countQuestions(): Int = dao.count()
    suspend fun search(keyword: String): List<QuestionEntity> {
        if (keyword.isBlank()) return emptyList()
        return dao.searchByKeyword(keyword.trim())
    }
}