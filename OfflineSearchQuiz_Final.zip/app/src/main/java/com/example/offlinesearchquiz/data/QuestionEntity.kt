package com.example.offlinesearchquiz.data
import androidx.room.*
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
@Entity(tableName = "questions")
@TypeConverters(QuestionConverters::class)
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @SerializedName("src") val src: String = "",
    @SerializedName("cat") val cat: String = "",
    @SerializedName("type") val type: String = "",
    @SerializedName("q") val q: String = "",
    @SerializedName("o") val o: List<String>? = null,
    @SerializedName("ai") val ai: List<Int>? = null,
    @SerializedName("at") val at: String = "",
    @SerializedName("ex") val ex: String = ""
)
class QuestionConverters {
    @TypeConverter fun fromStringList(value: List<String>?): String = Gson().toJson(value)
    @TypeConverter fun toStringList(value: String?): List<String>? { if (value.isNullOrEmpty()) return null; return Gson().fromJson(value, object : TypeToken<List<String>>() {}.type) }
    @TypeConverter fun fromIntList(value: List<Int>?): String = Gson().toJson(value)
    @TypeConverter fun toIntList(value: String?): List<Int>? { if (value.isNullOrEmpty()) return null; return Gson().fromJson(value, object : TypeToken<List<Int>>() {}.type) }
}