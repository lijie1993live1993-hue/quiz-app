package com.example.offlinesearchquiz.practice
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun PracticeScreen(vm: QuizViewModel = viewModel()) {
    val questions by vm.questions.collectAsState()
    val currentIndex by vm.currentIndex.collectAsState()
    val showAnswer by vm.showAnswer.collectAsState()

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("题库为空，请先在搜题页导入 JSON 题库") }
        return
    }

    val q = questions[currentIndex]

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("第 ${currentIndex + 1} / ${questions.size} 题", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(q.q, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        if (!q.o.isNullOrEmpty()) {
            q.o.forEachIndexed { index, optionText ->
                val isCorrect = q.ai?.contains(index) == true
                val color = if (showAnswer && isCorrect) Color.Green else MaterialTheme.colorScheme.onSurface
                Text("${('A' + index)}. $optionText", color = color, modifier = Modifier.padding(vertical = 4.dp))
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        if (showAnswer) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (q.at.isNotBlank()) Text("答案：${q.at}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    if (!q.ai.isNullOrEmpty() && q.at.isBlank()) {
                        val ans = q.ai.map { ('A' + it) }.joinToString(", ")
                        Text("答案：$ans", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    if (q.ex.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text("解析：${q.ex}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = vm::prev, enabled = currentIndex > 0) { Text("上一题") }
            Button(onClick = vm::toggleAnswer) { Text(if (showAnswer) "隐藏答案" else "查看答案") }
            Button(onClick = vm::next, enabled = currentIndex < questions.size - 1) { Text("下一题") }
        }
    }
}