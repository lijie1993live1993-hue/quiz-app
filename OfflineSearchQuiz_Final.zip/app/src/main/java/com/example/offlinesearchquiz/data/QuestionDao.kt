package com.example.offlinesearchquiz.data
import androidx.room.*
@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions WHERE q LIKE '%' || :keyword || '%' LIMIT 50")
    suspend fun searchByKeyword(keyword: String): List<QuestionEntity>
    @Query("SELECT * FROM questions")
    suspend fun getAllQuestions(): List<QuestionEntity>
    @Query("SELECT COUNT(*) FROM questions") suspend fun count(): Int
    @Query("DELETE FROM questions") suspend fun clearAll()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(questions: List<QuestionEntity>)
}