package com.example.offlinesearchquiz
import android.app.Application
class QuizApp : Application()