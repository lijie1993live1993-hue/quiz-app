package com.example.offlinesearchquiz
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinesearchquiz.camera.CameraActivity
import com.example.offlinesearchquiz.floating.FloatingPermissionHelper
import com.example.offlinesearchquiz.floating.FloatingWindowService
import com.example.offlinesearchquiz.search.SearchCenterScreen
import com.example.offlinesearchquiz.search.SearchViewModel

class MainActivity : ComponentActivity() {
    private lateinit var vm: SearchViewModel
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data?.getStringExtra("ocr_text").orEmpty()
            if (text.isNotBlank()) vm.searchRecognizedText(text)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    vm = viewModel()
                    SearchCenterScreen(onOpenCamera = { cameraLauncher.launch(Intent(this, CameraActivity::class.java)) })
                }
            }
        }
        if (!FloatingPermissionHelper.canDrawOverlay(this)) FloatingPermissionHelper.openOverlaySettings(this)
        else startForegroundService(Intent(this, FloatingWindowService::class.java))
    }
}