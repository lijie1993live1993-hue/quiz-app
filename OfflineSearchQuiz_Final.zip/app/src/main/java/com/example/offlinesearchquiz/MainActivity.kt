package com.example.offlinesearchquiz
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.offlinesearchquiz.camera.CameraActivity
import com.example.offlinesearchquiz.floating.FloatingPermissionHelper
import com.example.offlinesearchquiz.floating.FloatingWindowService
import com.example.offlinesearchquiz.practice.PracticeScreen
import com.example.offlinesearchquiz.search.SearchScreen
import com.example.offlinesearchquiz.search.SearchViewModel

class MainActivity : ComponentActivity() {
    private lateinit var vm: SearchViewModel
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data?.getStringExtra("ocr_text").orEmpty()
            if (text.isNotBlank()) vm.searchRecognizedText(text)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                vm = viewModel()
                var selectedTab by remember { mutableIntStateOf(0) }
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(icon = { Icon(Icons.Default.Search, null) }, label = { Text("搜题") }, selected = selectedTab == 0, onClick = { selectedTab = 0 })
                            NavigationBarItem(icon = { Icon(Icons.Default.Edit, null) }, label = { Text("刷题") }, selected = selectedTab == 1, onClick = { selectedTab = 1 })
                        }
                    }
                ) { padding ->
                    Surface(modifier = Modifier.padding(padding)) {
                        if (selectedTab == 0) {
                            SearchScreen(onOpenCamera = { cameraLauncher.launch(Intent(this, CameraActivity::class.java)) }, vm = vm)
                        } else {
                            PracticeScreen()
                        }
                    }
                }
            }
        }
        if (!FloatingPermissionHelper.canDrawOverlay(this)) FloatingPermissionHelper.openOverlaySettings(this)
        else startForegroundService(Intent(this, FloatingWindowService::class.java))
    }
}