package com.example.offlinesearchquiz.voice
import android.content.Context
class SherpaAsrManager(private val context: Context) {
    suspend fun recognizeOnce(): String { return "" }
}