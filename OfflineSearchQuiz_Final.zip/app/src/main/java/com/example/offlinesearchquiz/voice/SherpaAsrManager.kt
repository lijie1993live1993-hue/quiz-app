package com.example.offlinesearchquiz.voice
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.io.FileOutputStream

class SherpaAsrManager(private val context: Context) {
    private var recognizer: OfflineRecognizer? = null

    private fun copyAssetIfNotExists(assetName: String, targetFile: File): Boolean {
        if (targetFile.exists()) return true
        return try {
            context.assets.open(assetName).use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            true
        } catch (e: Exception) {
            Log.e("Sherpa", "Copy asset failed: $assetName", e)
            false
        }
    }

    private fun initAsr(): Boolean {
        if (recognizer != null) return true
        val modelDir = File(context.filesDir, "sherpa-model")
        if (!modelDir.exists()) modelDir.mkdirs()
        
        val modelFile = File(modelDir, "model.int8.onnx")
        val tokensFile = File(modelDir, "tokens.txt")

        if (!modelFile.exists()) copyAssetIfNotExists("sherpa-model/model.int8.onnx", modelFile)
        if (!tokensFile.exists()) copyAssetIfNotExists("sherpa-model/tokens.txt", tokensFile)

        if (!modelFile.exists() || !tokensFile.exists()) {
            Log.e("Sherpa", "Model files not found in assets or storage.")
            return false
        }

        try {
            val config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    paraformer = OfflineParaformerModelConfig(model = modelFile.absolutePath),
                    tokens = tokensFile.absolutePath,
                    numThreads = 2,
                    modelType = "paraformer",
                    debug = false,
                    provider = "cpu"
                ),
                decodingMethod = "greedy_search"
            )
            recognizer = OfflineRecognizer(null, config)
            return true
        } catch (e: Exception) {
            Log.e("Sherpa", "Init failed", e)
            return false
        }
    }

    suspend fun recognizeOnce(): String {
        if (!initAsr()) return ""
        val r = recognizer ?: return ""

        val sampleRate = 16000
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return ""
        
        val audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        val samples = FloatArray(sampleRate * 3)
        audioRecord.startRecording()
        
        var readTotal = 0
        while (readTotal < samples.size) {
            val buffer = ShortArray(bufferSize / 2)
            val read = audioRecord.read(buffer, 0, buffer.size)
            if (read > 0) {
                for (i in 0 until read) {
                    if (readTotal < samples.size) {
                        samples[readTotal++] = buffer[i] / 32768.0f
                    }
                }
            }
        }
        audioRecord.stop()
        audioRecord.release()

        val stream = r.createStream()
        stream.acceptWaveform(samples, sampleRate)
        r.decode(stream)
        val result = r.getResult(stream)
        stream.release()
        return result.text
    }
}