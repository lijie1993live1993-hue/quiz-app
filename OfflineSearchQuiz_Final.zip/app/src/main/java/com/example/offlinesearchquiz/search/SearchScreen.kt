package com.example.offlinesearchquiz.search
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun SearchScreen(onOpenCamera: () -> Unit, vm: SearchViewModel = viewModel()) {
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importQuestionsFromUri(uri)
    }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(
            value = vm.query.collectAsState().value, onValueChange = vm::onQueryChange,
            modifier = Modifier.fillMaxWidth(), placeholder = { Text("输入题目关键词…") },
            trailingIcon = { IconButton(onClick = vm::searchText) { Icon(Icons.Default.Search, "搜索") } }, singleLine = true
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("导入题库") }
            Button(onClick = onOpenCamera, modifier = Modifier.weight(1f)) { Text("拍照搜题") }
            Button(onClick = { vm.startVoiceSearch() }, modifier = Modifier.weight(1f)) { Text("语音搜题") }
        }
        vm.importMessage.collectAsState().value?.let { Text(it, color = Color.Green) }
        vm.error.collectAsState().value?.let { Text(it, color = Color.Red) }
        if (vm.isLoading.collectAsState().value) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        
        vm.result.collectAsState().value.forEach { item ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(item.q, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    if (!item.o.isNullOrEmpty()) {
                        item.o.forEachIndexed { index, optionText ->
                            val isCorrect = item.ai?.contains(index) == true
                            Text("${('A' + index)}. $optionText", color = if (isCorrect) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface, fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                    if (item.at.isNotBlank()) Text("答案：${item.at}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}