package com.example.offlinesearchquiz.search
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinesearchquiz.data.QuestionEntity
import com.example.offlinesearchquiz.data.QuestionRepository
import com.example.offlinesearchquiz.voice.SherpaAsrManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
class SearchViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = QuestionRepository(app)
    private val asr = SherpaAsrManager(app)
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query
    private val _result = MutableStateFlow<List<QuestionEntity>>(emptyList())
    val result: StateFlow<List<QuestionEntity>> = _result
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _importMessage = MutableStateFlow<String?>(null)
    val importMessage: StateFlow<String?> = _importMessage

    fun onQueryChange(v: String) { _query.value = v }
    fun searchText() = doSearch(_query.value)
    fun searchRecognizedText(text: String) { _query.value = text; doSearch(text) }
    private fun doSearch(keyword: String) {
        if (keyword.isBlank()) return
        viewModelScope.launch {
            _isLoading.value = true; _result.value = repo.search(keyword); _isLoading.value = false
        }
    }
    fun importQuestionsFromUri(uri: Uri, clearFirst: Boolean = false) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val jsonText = getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (jsonText.isNullOrBlank()) { _error.value = "文件为空"; return@launch }
                repo.importFromJsonText(jsonText, clearFirst)
                _error.value = null; _importMessage.value = "导入成功，共 ${repo.countQuestions()} 题"
            } catch (e: Exception) { _error.value = "导入失败：${e.message}" } finally { _isLoading.value = false }
        }
    }
    fun startVoiceSearch() {
        viewModelScope.launch {
            _isLoading.value = true
            val text = asr.recognizeOnce()
            _isLoading.value = false
            if (text.isNotBlank()) {
                searchRecognizedText(text)
                _error.value = null
            } else {
                _error.value = "未识别到声音或缺少模型"
            }
        }
    }
}