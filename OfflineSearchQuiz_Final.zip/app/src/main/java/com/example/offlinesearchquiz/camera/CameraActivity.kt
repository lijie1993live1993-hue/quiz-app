package com.example.offlinesearchquiz.camera
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class CameraActivity : ComponentActivity() {
    private var imageCapture: ImageCapture? = null
    private var isRecognizing = false
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (!it) finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
        setContent {
            val context = LocalContext.current
            val lifecycleOwner = LocalLifecycleOwner.current
            val previewView = androidx.compose.runtime.remember { PreviewView(context) }
            
            androidx.compose.runtime.LaunchedEffect(Unit) {
                val provider = ProcessCameraProvider.getInstance(context).get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                
                // 使用 ImageAnalysis 进行实时扫描
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                
                imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (isRecognizing) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    
                    isRecognizing = true
                    OcrProcessor.recognizeImageProxy(imageProxy, onSuccess = { text ->
                        imageProxy.close()
                        if (text.length > 5) { // 识别到一定长度的文本才返回
                            runOnUiThread {
                                setResult(RESULT_OK, Intent().putExtra("ocr_text", text))
                                finish()
                            }
                        } else {
                            isRecognizing = false // 文本太短，忽略并继续识别
                        }
                    }, onFailure = {
                        imageProxy.close()
                        isRecognizing = false
                    })
                }

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis)
            }
            
            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                
                // 扫描框 UI
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.8f)
                        .height(200.dp)
                        .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("将题目放入框内，自动识别中...", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}