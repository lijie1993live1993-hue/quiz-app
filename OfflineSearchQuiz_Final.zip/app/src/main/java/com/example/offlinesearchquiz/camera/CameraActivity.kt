package com.example.offlinesearchquiz.camera
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class CameraActivity : ComponentActivity() {
    private var imageCapture: ImageCapture? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (!it) finish() }.launch(Manifest.permission.CAMERA)
        }
        setContent {
            val context = LocalContext.current
            val lifecycleOwner = LocalLifecycleOwner.current
            val previewView = androidx.compose.runtime.remember { PreviewView(context) }
            androidx.compose.runtime.LaunchedEffect(Unit) {
                val provider = ProcessCameraProvider.getInstance(context).get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().build()
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            }
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                AndroidView(factory = { previewView }, modifier = Modifier.weight(1f).fillMaxWidth())
                Button(onClick = {
                    val file = java.io.File(cacheDir, "ocr.jpg")
                    imageCapture?.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            val bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                            lifecycleScope.launch {
                                val text = OcrProcessor.recognize(bitmap)
                                setResult(RESULT_OK, Intent().putExtra("ocr_text", text))
                                finish()
                            }
                        }
                        override fun onError(exception: ImageCaptureException) { finish() }
                    })
                }, modifier = Modifier.padding(24.dp)) { Text("拍照并识别") }
            }
        }
    }
}