package com.example.offlinesearchquiz.floating
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.example.offlinesearchquiz.MainActivity

class FloatingWindowService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        val channel = NotificationChannel("floating", "悬浮搜题", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        startForeground(1001, NotificationCompat.Builder(this, "floating").setContentTitle("悬浮搜题").setSmallIcon(android.R.drawable.ic_menu_search).build())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowService)
            setViewTreeViewModelStoreOwner(this@FloatingWindowService)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowService)
            setContent {
                Box(modifier = Modifier.size(56.dp).background(Color(0xFF3F51B5), CircleShape).clickable {
                    startActivity(Intent(this@FloatingWindowService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Search, null, tint = Color.White)
                }
            }
        }
        params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 200; y = 600
        }
        windowManager.addView(composeView, params)
        composeView?.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_MOVE) {
                params.x = event.rawX.toInt() - 80; params.y = event.rawY.toInt() - 80
                windowManager.updateViewLayout(composeView, params)
            }
            false
        }
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }
    override fun onDestroy() { lifecycleRegistry.currentState = Lifecycle.State.DESTROYED; composeView?.let { runCatching { windowManager.removeView(it) } }; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}