package com.example.offlinesearchquiz.floating
import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.offlinesearchquiz.MainActivity
import com.example.offlinesearchquiz.search.SearchViewModel

@SuppressLint("ForegroundServiceType")
class FloatingWindowService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)
    
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private lateinit var searchViewModel: SearchViewModel

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        val channel = NotificationChannel("floating", "悬浮搜题", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        startForeground(1001, NotificationCompat.Builder(this, "floating").setContentTitle("悬浮搜题运行中").setSmallIcon(android.R.drawable.ic_menu_search).build())
        
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        searchViewModel = SearchViewModel(application)
        
        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowService)
            setViewTreeViewModelStoreOwner(this@FloatingWindowService)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowService)
            setContent {
                MaterialTheme {
                    FloatingSearchPanel()
                }
            }
        }
        
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        
        windowManager.addView(composeView, params)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    @Composable
    private fun FloatingSearchPanel() {
        val query by searchViewModel.query.collectAsState()
        val results by searchViewModel.result.collectAsState()
        
        var panelWidth by remember { mutableFloatStateOf(0.9f) }
        
        // 动态更新悬浮窗尺寸
        LaunchedEffect(panelWidth) {
            val displayMetrics = resources.displayMetrics
            params.width = (displayMetrics.widthPixels * panelWidth).toInt()
            windowManager.updateViewLayout(composeView, params)
        }

        Card(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // 顶部拖动栏与控制按钮
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                params.x += dragAmount.x.toInt()
                                params.y += dragAmount.y.toInt()
                                windowManager.updateViewLayout(composeView, params)
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("拖动此区域移动", fontSize = 12.sp, color = Color.Gray)
                    Row {
                        IconButton(onClick = { if (panelWidth > 0.5f) panelWidth -= 0.1f }, modifier = Modifier.size(24.dp)) { Icon(Icons.Default.Remove, "缩小") }
                        IconButton(onClick = { if (panelWidth < 1.0f) panelWidth += 0.1f }, modifier = Modifier.size(24.dp)) { Icon(Icons.Default.Add, "放大") }
                        IconButton(onClick = { stopSelf() }, modifier = Modifier.size(24.dp)) { Icon(Icons.Default.Close, "关闭", tint = Color.Red) }
                    }
                }
                Divider(modifier = Modifier.padding(bottom = 8.dp), color = Color.LightGray)
                
                // 搜索栏
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = searchViewModel::onQueryChange,
                        modifier = Modifier.weight(1f).height(50.dp),
                        placeholder = { Text("输入关键字...", fontSize = 14.sp) },
                        singleLine = true
                    )
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = { searchViewModel.searchText() }) { Icon(Icons.Default.Search, "搜") }
                    IconButton(onClick = { searchViewModel.startVoiceSearch() }) { Icon(Icons.Default.Mic, "语") }
                    IconButton(onClick = { 
                        val intent = Intent(this@FloatingWindowService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("open_camera", true)
                        }
                        startActivity(intent)
                    }) { Icon(Icons.Default.CameraAlt, "拍") }
                }
                
                // 结果区域
                if (results.isNotEmpty()) {
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 250.dp)) {
                        items(results) { item ->
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text(item.q, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (item.at.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text("答：${item.at}", color = Color.Blue, fontSize = 13.sp, maxLines = 3)
                                }
                            }
                            Divider(color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() { 
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        composeView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy() 
    }
    override fun onBind(intent: Intent?): IBinder? = null
}