package com.example.offlinesearchquiz.practice
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.offlinesearchquiz.data.QuestionEntity
import com.example.offlinesearchquiz.data.QuestionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
class QuizViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = QuestionRepository(app)
    private val _questions = MutableStateFlow<List<QuestionEntity>>(emptyList())
    val questions: StateFlow<List<QuestionEntity>> = _questions
    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex
    private val _showAnswer = MutableStateFlow(true)
    val showAnswer: StateFlow<Boolean> = _showAnswer

    init { loadQuestions() }

    fun loadQuestions() {
        viewModelScope.launch {
            _questions.value = repo.getAll()
            _currentIndex.value = 0
            _showAnswer.value = true
        }
    }
    fun next() { if (_currentIndex.value < _questions.value.size - 1) { _currentIndex.value++; _showAnswer.value = true } }
    fun prev() { if (_currentIndex.value > 0) { _currentIndex.value--; _showAnswer.value = true } }
    fun toggleAnswer() { _showAnswer.value = !_showAnswer.value }
}